<?php 
session_start(); 

session_destroy();

?>
<!DOCTYPE html>
<html>

<!-- Mirrored from adminlte.io/themes/v3/pages/examples/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Jan 2020 17:08:12 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="./assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="./assets/fonts/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="./assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="./assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <span><b>Login</b></span>
  </div>
        <?php if(isset($_SESSION['success'])){?>
          <div class="alert alert-success alert-dismissible mt-4">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo $_SESSION['success'];?>
          </div>
        <?php unset($_SESSION['success']); } ?>

        <?php if(isset($_SESSION['error'])){?>
          <div class="alert alert-danger alert-dismissible mt-4">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo $_SESSION['error'];?>
          </div>
        <?php unset($_SESSION['error']); } ?>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">

  
        
        <div class="alert-credentials"></div>
        
        <div class="input-group mb-3">
          <input type="email" class="form-control email" name="email" placeholder="Email">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control password" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>

      <div class="social-auth-links text-center mb-3">
        <span class="btn btn-block btn-primary" style="cursor: pointer;"  onclick="login()">
          <i class="fa fa-sign-in-alt mr-2"></i>Sign in  
        </span>
      </div>
      <!-- /.social-auth-links -->

    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- Bootstrap 4 -->
<script src="./assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
  function login()
  {
    var email = document.getElementsByClassName('email')[0].value;
    var password = document.getElementsByClassName('password')[0].value;
	var creds = "email="+email+"&password="+password;
    var Html = '';
    if(email !== '' && password !== '')
    {
        document.getElementsByClassName('email')[0].style.borderColor = '';
        document.getElementsByClassName('password')[0].style.borderColor = '';

			var response = '';
            var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "getLoginCredentialsUsingAjax.php", true);
            xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

			xhttp.onreadystatechange = function() {
              if (xhttp.readyState == 4 && xhttp.status == 200) 
              {
				            
				   var response = xhttp.responseText;
                console.log(xhttp.responseText);

                console.log('\nlog: ' + JSON.stringify(xhttp));
                if(response != '')
                {
				console.log("HI Moshsin");
           
                    Html += '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                    Html += '<strong>Success!</strong> User Verified';
                    Html += '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
                    Html += '<span aria-hidden="true">&times;</span>';
                    Html += '</button>';
                    Html += '</div>';
                    //$('.alert-credentials').empty();
                    //$('.alert-credentials').append(Html);
					document.getElementsByClassName('alert-credentials')[0].innerHtml = "";
                    document.getElementsByClassName('alert-credentials')[0].innerHtml = Html; 
                   
				   setTimeout(function(){window.location = "create-collection.php";},3000);
                   	}
                  else
                  {

                    Html += '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                    Html += '<strong>Error!</strong> Invalid username or password';
                    Html += '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
                    Html += '<span aria-hidden="true">&times;</span>';
                    Html += '</button>';
                    Html += '</div>';
                    document.getElementsByClassName('alert-credentials')[0].innerHtml = "";
                    document.getElementsByClassName('alert-credentials')[0].innerHtml = Html;
                   // $('.alert-credentials').empty();
                   // $('.alert-credentials').append(Html);


                }


              }
            };
            xhttp.send(encodeURI(creds));
			
      
		}
	
		else
		{
		  if(email === '')
			document.getElementsByClassName('email')[0].style.borderColor = 'red';
		  if(password === '')
			document.getElementsByClassName('password')[0].style.borderColor = 'red';

		}




	}
  
</script>



</body>

<!-- Mirrored from adminlte.io/themes/v3/pages/examples/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Jan 2020 17:08:12 GMT -->
</html>
