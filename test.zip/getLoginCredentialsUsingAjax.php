<?php

if(isset($_POST['email']))
{
	include 'getData.php';
	$email = $_POST['email'];
	$password = $_POST['password'];

	$getData = new getData();

	// die($password);
	$recordcount = $getData->login($email, $password);

	echo($recordcount);
}

?>