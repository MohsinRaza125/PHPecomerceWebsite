<?php

$abrands = array();
$acolors = array();
$asize = array();
$sSearchData = '';
if(array_key_exists('brand', $_REQUEST))
	$brands = $_REQUEST['brand'];
if(array_key_exists('colors', $_REQUEST))
	$colors = $_REQUEST['colors'];
if(array_key_exists('size', $_REQUEST))
	$size = $_REQUEST['size'];
//include './getData.php';

if(!empty($brands)) $abrands = explode(',', $brands);
if(!empty($colors)) $acolors = explode(',', $colors);
if(!empty($size)) $asize = explode(',', $size);

//$getData = new getData();
function getFilteredData($brands = null, $colors = null, $size = null)
	{
		$sBrands = '';
		$sColors = '';
		$sSize = '';
		$filteredData = array();
		$iCounter = 0;

		if(count($brands) > 0)
		{
			$sBrands = 'brand IN(';
			foreach ($brands as $key => $value) 
			{
				$sBrands .= '"'.$value .'",';
			}
			$sBrands = substr($sBrands, 0, -1);
			$sBrands .= ')';
		}



		if(count($colors) > 0)
		{
			if(count($brands) > 0)
				$sColors = ' AND ';
			$sColors .= 'color IN(';
			foreach ($colors as $key => $value) 
			{
				$sColors .= '"'.$value.'",';
			}
			$sColors = substr($sColors, 0, -1);
			$sColors .= ')';
		} 

		if(count($size) > 0)
		{
			if(count($colors) > 0)
				$sSize = ' AND ';
			$sSize .= 'size IN(';
			foreach ($size as $key => $value) 
			{
				$sSize .= $value .',';
			}
			$sSize = substr($sSize, 0, -1);
			$sSize .= ')';
		}			

		if(count($brands) > 0 || count($colors) > 0 || count($size))
		{
			$sql = "SELECT product_id, brand, color, size, price, sold FROM collections WHERE $sBrands $sColors $sSize";

			include './database/connection.php';

			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
			    // output data of each row
			    while($row = $result->fetch_assoc()) 
			    {
			    	$filteredData[$iCounter]['product_id'] = $row['product_id']; 
			    	$filteredData[$iCounter]['brand'] = $row['brand']; 
			    	$filteredData[$iCounter]['size'] = $row['size']; 
			    	$filteredData[$iCounter]['price'] = $row['price']; 
			    	$filteredData[$iCounter]['color'] = $row['color']; 
			    	$filteredData[$iCounter]['sold'] = $row['sold']; 
			    	$iCounter++;
			    }
			}

			include './database/connection_close.php';

			return $filteredData;			
		}
	}

$getFilteredData = getFilteredData($abrands, $acolors, $asize);
if(!empty($getFilteredData))
{
	$sSearchData .= '<input type="hidden" name="counter" class="counter" value='.count($getFilteredData).'>';
	foreach ($getFilteredData as $key => $value) 
	{
		$sSearchData .= '<div class="col-lg-6" style="margin-top:10px;">';
		$sSearchData .= '<div class="card">';
		$sSearchData .= '<div class="card-body">';

		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Product ID :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= $value['product_id'];
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';


		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Brand :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= $value['brand'];
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';


		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Size :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= number_format($value['size'],1);
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';

		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Price :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= number_format($value['price'],2);
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';

		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Color :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= $value['color'];
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';

		$sSearchData .= '<div class="container">';
		$sSearchData .= '<div class="row">';
		$sSearchData .= '<div class="col-lg-7">';
		$sSearchData .= '<b>Sold :</b>';
		$sSearchData .= '</div>';
		$sSearchData .= '<div class="col-lg-5">';
		$sSearchData .= $value['sold'];
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
		$sSearchData .= '</div>';
	}
}
else
{
	$sSearchData .= '<input type="hidden" name="counter" class="counter" value="0">';
}

echo $sSearchData;

?>