/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.4.11-MariaDB : Database - assignment_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`assignment_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `assignment_db`;

/*Table structure for table `collections` */

DROP TABLE IF EXISTS `collections`;

CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `size` double(11,4) DEFAULT 0.0000,
  `price` double(11,4) DEFAULT 0.0000,
  `sold` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

/*Data for the table `collections` */

insert  into `collections`(`id`,`product_id`,`brand`,`color`,`size`,`price`,`sold`,`status`,`created_at`,`updated_at`) 
values (1,'T-101','DELL','White',15.0000,22.5000,12,1,'2020-04-24 01:00:01',NULL),
       (2,'T-102','DELL','Black',15.0000,300.0000,50,1,NULL,NULL),
	   (3,'T-103','ACER','Rose Gold',15.0000,300.0000,50,1,NULL,NULL),
	   (4,'T-104','ACER','Silver',15.0000,300.0000,50,1,NULL,NULL),
	   (5,'T-105','ACER','Grey',15.0000,300.0000,50,1,NULL,NULL),
	   (6,'T-106','ACER','White',15.0000,300.0000,50,1,NULL,NULL),
	   (7,'T-107','ACER','Black',13.0000,300.0000,10,1,NULL,NULL),
	   (8,'T-108','HP','Grey',15.0000,400.0000,10,1,NULL,NULL),
	   (9,'T-109','HP','Black',13.0000,400.0000,10,1,NULL,NULL),
	   (10,'T-110','HP','Black',13.0000,400.0000,10,1,NULL,NULL),
	   (11,'T-111','HP','White',13.0000,400.0000,10,1,NULL,NULL),
	   (12,'T-112','HP','Black',13.0000,400.0000,70,1,NULL,NULL),
	   (13,'T-113','HP','Grey',21.0000,800.0000,70,1,NULL,NULL),
	   (14,'T-114','HP','Black',21.0000,800.0000,70,1,NULL,NULL),
	   (15,'T-115','HP','White',21.0000,800.0000,70,1,NULL,NULL),
	   (16,'T-116','HP','Black',17.0000,800.0000,70,1,NULL,NULL),
	   (17,'T-117','HP','Black',17.0000,800.0000,70,1,NULL,NULL),
	   (18,'T-118','ACER','Silver',15.0000,1500.0000,60,1,NULL,NULL),
	   (19,'T-119','ACER','Rose Gold',17.0000,1500.0000,60,1,NULL,NULL),
	   (20,'T-1500','ACER','Grey',15.0000,1500.0000,60,1,NULL,NULL),
	   (21,'T-121','ACER','Rose Gold',19.0000,1500.0000,60,1,NULL,NULL),
	   (22,'T-122','ACER','White',21.0000,1500.0000,60,1,NULL,NULL),
	   (23,'T-123','DELL','Black',21.0000,1500.0000,60,1,NULL,NULL),
	   (24,'T-124','DELL','Silver',21.0000,1500.0000,60,1,NULL,NULL),
	   (25,'T-126','DELL','Black',15.0000,500.0000,22,1,NULL,NULL),
	   (26,'T-126','DELL','White',15.0000,500.0000,22,1,NULL,NULL),
	   (27,'T-127','DELL','Black',15.0000,500.0000,60,1,NULL,NULL),
	   (28,'T-128','DELL','Grey',13.0000,500.0000,60,1,NULL,NULL),
	   (29,'T-129','DELL','Black',13.0000,500.0000,60,1,NULL,NULL),
	   (30,'T-130','Apple','Silver',13.0000,1997.0000,40,1,NULL,NULL),
	   (31,'T-131','Apple','Silver',13.0000,1997.0000,40,1,NULL,NULL),
	   (32,'T-132','Apple','White',17.0000,1997.0000,40,1,NULL,NULL),
	   (33,'T-133','Apple','Grey',17.0000,1997.0000,40,1,NULL,NULL),
	   (34,'T-134','Apple','Silver',17.0000,3500.0000,40,1,NULL,NULL),
	   (35,'T-135','Apple','Silver',17.0000,3500.0000,40,1,NULL,NULL),
	   (36,'T-136','Apple','Silver',17.0000,3500.0000,40,1,NULL,NULL),
	   (37,'T-137','Apple','White',15.0000,3500.0000,22,1,NULL,NULL),
	   (38,'T-138','Apple','Grey',15.0000,3500.0000,22,1,NULL,NULL),
	   (39,'T-139','Apple','Silver',15.0000,3500.0000,22,1,NULL,NULL),
	   (40,'T-140','Apple','Silver',15.0000,500.0000,22,1,NULL,NULL),
	   (41,'T-141','ASUS','Black',15.0000,500.0000,22,1,NULL,NULL),
	   (42,'T-142','ASUS','White',17.0000,500.0000,22,1,NULL,NULL),
	   (43,'T-143','ASUS','Black',17.0000,500.0000,22,1,NULL,NULL),
	   (44,'T-144','ASUS','Black',17.0000,500.0000,40,1,NULL,NULL),
	   (45,'T-145','ASUS','Grey',17.0000,500.0000,40,1,NULL,NULL),
	   (46,'T-146','ASUS','Black',15.0000,120.0000,40,1,NULL,NULL),
	   (47,'T-147','ASUS','White',15.0000,120.0000,40,1,NULL,NULL),
	   (48,'T-148','ASUS','Black',15.0000,120.0000,40,1,NULL,NULL),
	   (49,'T-149','ASUS','Black',15.0000,120.0000,35,1,NULL,NULL),
	   (50,'T-150','ASUS','Black',17.0000,120.0000,35,1,NULL,NULL),
	   (51,'T-151','ASUS','White',17.0000,600.0000,35,1,NULL,NULL),
	   (52,'T-152','ASUS','Grey',17.0000,600.0000,35,1,NULL,NULL),
	   (53,'T-153','ASUS','Rose Gold',17.0000,600.0000,35,1,NULL,NULL),
	   (54,'T-154','ASUS','Rose Gold',17.0000,600.0000,35,1,NULL,NULL),
	   (55,'T-155','ASUS','Rose Gold',17.0000,600.0000,35,1,NULL,NULL),
	   (56,'T-156','ASUS','Grey',17.0000,700.0000,35,1,NULL,NULL),
	   (57,'T-157','ASUS','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
	   (58,'T-158','ASUS','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
	   (59,'T-159','ASUS','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
	   (60,'T-160','ASUS','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
	   (61,'T-161','Lenovo','Silver',17.0000,700.0000,5,1,NULL,NULL),
	   (62,'T-162','Lenovo','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
	   (63,'T-163','Lenovo','Rose Gold',17.0000,700.0000,5,1,NULL,NULL),
		(64,'T-164','Lenovo','Rose Gold',17.0000,700.0000,15,1,NULL,NULL),
		(65,'T-165','Lenovo','Grey',17.0000,900.0000,15,1,NULL,NULL),
		(66,'T-166','Lenovo','Rose Gold',17.0000,900.0000,15,1,NULL,NULL),
		(67,'T-167','Lenovo','Rose Gold',17.0000,900.0000,15,1,NULL,NULL),
		(68,'T-168','Lenovo','Rose Gold',15.0000,900.0000,15,1,NULL,NULL),
		(69,'T-169','Lenovo','Rose Gold',15.0000,900.0000,15,1,NULL,NULL),
		(70,'T-170','Lenovo','Grey',15.0000,900.0000,15,1,NULL,NULL),
		(71,'T-171','Microsoft Surface','Black',13.0000,900.0000,15,1,NULL,NULL),
		(72,'T-172','Microsoft Surface','Rose Gold',13.0000,1000.0000,22,1,NULL,NULL),
		(73,'T-173','Microsoft Surface','Rose Gold',13.0000,1000.0000,22,1,NULL,NULL),
		(74,'T-174','Microsoft Surface','Grey',13.0000,1000.0000,22,1,NULL,NULL),
		(75,'T-175','Microsoft Surface','White',13.0000,1000.0000,22,1,NULL,NULL),
		(76,'T-176','Microsoft Surface','Rose Gold',21.0000,1000.0000,22,1,NULL,NULL),
		(77,'T-177','Microsoft Surface','Rose Gold',21.0000,1000.0000,22,1,NULL,NULL),
		(78,'T-178','Microsoft Surface','Grey',21.0000,1000.0000,22,1,NULL,NULL),
		(79,'T-179','Microsoft Surface','Rose Gold',21.0000,1000.0000,22,1,NULL,NULL),
		(80,'T-180','Microsoft Surface','White',21.0000,1000.0000,22,1,NULL,NULL),
		(81,'T-181','Toshiba','Silver',17.0000,1000.0000,22,1,NULL,NULL),
		(82,'T-182','Toshiba','Rose Gold',17.0000,1000.0000,22,1,NULL,NULL),
		(83,'T-183','Toshiba','Rose Gold',17.0000,1200.0000,22,1,NULL,NULL),
		(84,'T-184','Toshiba','Rose Gold',17.0000,1200.0000,22,1,NULL,NULL),
		(85,'T-185','Toshiba','White',17.0000,1200.0000,22,1,NULL,NULL),
		(86,'T-186','Toshiba','Rose Gold',17.0000,1200.0000,22,1,NULL,NULL),
		(87,'T-187','Toshiba','Rose Gold',17.0000,1200.0000,20,1,NULL,NULL),
		(88,'T-188','Toshiba','Rose Gold',17.0000,1200.0000,20,1,NULL,NULL),
		(89,'T-189','Toshiba','Rose Gold',17.0000,1200.0000,20,1,NULL,NULL),
		(90,'T-190','Toshiba','White',17.0000,1200.0000,20,1,NULL,NULL),
		(91,'T-191','Samsung','Silver',17.0000,1200.0000,20,1,NULL,NULL),
		(92,'T-192','Samsung','Silver',21.0000,1200.0000,20,1,NULL,NULL),
		(93,'T-193','Samsung','Silver',21.0000,1200.0000,20,1,NULL,NULL),
		(94,'T-194','Samsung','Grey',21.0000,200.0000,20,1,NULL,NULL),
		(95,'T-195','Samsung','Silver',13.0000,200.0000,22,1,NULL,NULL),
		(96,'T-196','Samsung','White',13.0000,200.0000,22,1,NULL,NULL),
		(97,'T-197','Samsung','Silver',13.0000,500.0000,22,1,NULL,NULL),
		(98,'T-198','Samsung','Silver',15.0000,500.0000,22,1,NULL,NULL),
		(99,'T-199','Samsung','Grey',15.0000,500.0000,22,1,NULL,NULL),
		(100,'T-200','Samsung','White',15.0000,500.0000,22,1,NULL,NULL);
		
		
/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`email`,`password`,`status`) values (1,'Admin','admin@mail.com','123456789',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
