  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="./assets/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Collection/Items</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
			
		<li class="nav-item">
            <a href="filter.php" class="nav-link">
              <i class="nav-icon fas fa-binoculars"></i>
              <p>
                Customer Search
              </p>
            </a>
          </li>
		  
          <li class="nav-item">
            <a href="create-collection.php" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Collection
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="logs.php" class="nav-link">
              <i class="nav-icon fas fa-file-word"></i>
              <p>
                Logs
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="index.php" class="nav-link">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Signout
              </p>
            </a>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>